# 测试结果

`validation-20261013.zip` 收录代码、Markdown 报告、曲线、合成测试输入、验证日志、真实道路网络评测 CSV 及数据文件 SHA-256。压缩包内保留 `code/`、`documentation/`、`readme.md`、`testresult/` 的目录结构。

不包含 USA 原始数据或可执行文件。该目录上传时仅提交 ZIP；本 README 在 ZIP 的 `testresult/` 中保留，不作为该目录下的散文件上传。
