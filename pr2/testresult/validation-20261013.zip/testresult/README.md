# 测试结果

本压缩包只收录 `testresult/` 下的测试材料：合成测试输入（`sample.gr`）、自动化验证日志（`validation.log`）、真实道路网络评测 CSV（NY / BAY / COL）与同种子复现 CSV（`benchmark_repeat_0/1.csv`）、实验环境与数据 SHA-256（`experiment.json`）。

不包含 USA 原始道路数据、代码、报告或可执行文件：代码与报告见仓库中的 `code/`、`documentation/`，二者不再复制进本压缩包。压缩包内保留 `testresult/` 目录结构，不平铺散文件；该目录上传时仅提交 ZIP，本 README 在 ZIP 的 `testresult/` 中保留，不作为该目录下的散文件上传。
